/*****************************************************************************
 * Copyright (C) 2009 Jean-Daniel Fekete and INRIA, France                  *
 * ------------------------------------------------------------------------- *
 * This software is published under the terms of the X11 Software License    *
 * a copy of which has been included with this distribution in the           *
 * license.txt file.                                                         *
 *****************************************************************************/
package infovis.graph.property;

import infovis.Graph;
import infovis.column.AbstractDoubleColumn;
import infovis.column.DoubleColumn;
import infovis.graph.Edge;
import infovis.graph.Vertex;
import infovis.graph.jung.JungWrapper;

/**
 * Class BetweennessCentrality
 * 
 * @author Jean-Daniel Fekete
 * @version $Revision$
 */
public class BetweennessCentrality extends DoubleColumn {
    protected Graph graph;
    /** Name of the optional Column containing the number of outgoing edges. */
    public static final String CENTRALITY_COLUMN = "[Betweenness Centrality]";
    /**
     * @param name
     * @param graph
     */
    protected BetweennessCentrality(Graph graph) {
        super(CENTRALITY_COLUMN);
        this.graph = graph;
    }
    

    /**
     * Updates the column
     */
//    @Override
    protected void update() {
//        try {
//            setReadOnly(false);
            edu.uci.ics.jung.graph.Graph<Vertex, Edge> g = JungWrapper.wrap(graph);
            edu.uci.ics.jung.algorithms.importance.BetweennessCentrality<Vertex, Edge> bc 
                = new edu.uci.ics.jung.algorithms.importance.BetweennessCentrality<Vertex, Edge>(
                        g, true, false);
//                {
//                    public void step() {
//                        System.out.println("Step in Betweenneess iteration");
//                        super.step();
//                    }
//                    /**
//                     * {@inheritDoc}
//                     */
//                    protected void finalizeIterations() {
//                        System.out.println("Finalize Betweenneess iteration");
//                        super.finalizeIterations();
//                    }
//            };
            bc.setRemoveRankScoresOnFinalize(false);
            bc.evaluate();
            
            int zeros = 0;
            for (Vertex v : g.getVertices()) {
                double d = bc.getVertexRankScore(v);
                if (d == 0)
                    zeros++;
                setExtend(v.getId(), d);
            }
            System.out.println("Betweenness computed with "+zeros+" zeros over "+size());
//        }
//        finally {
//            setReadOnly(true);
//        }
        
    }
    
    

    /**
     * Returns the out degree column associated with a graph, creating it
     * if required.
     *
     * @param graph the graph.
     *
     * @return the out degree column associated with the graph.
     */
    public static AbstractDoubleColumn getColumn(Graph graph) {
        AbstractDoubleColumn bcColumn =
            AbstractDoubleColumn.getColumn(
                    graph.getVertexTable(),
                CENTRALITY_COLUMN);
        if (bcColumn == null) {
            BetweennessCentrality centrality = new BetweennessCentrality(graph);
            try {
                centrality.update();
            }
            catch(Exception e) {
                e.printStackTrace();
            }
            bcColumn = centrality;
            graph.getVertexTable().addColumn(centrality);
        }
        return bcColumn;
    }
}
