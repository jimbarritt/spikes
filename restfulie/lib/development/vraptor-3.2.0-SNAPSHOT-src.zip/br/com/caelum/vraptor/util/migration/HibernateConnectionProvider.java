/***
 * Copyright (c) 2009 Caelum - www.caelum.com.br/opensource
 * All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * 	http://www.apache.org/licenses/LICENSE-2.0 
 * 
 * Unless required by applicable law or agreed to in writing, software 
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 */
package br.com.caelum.vraptor.util.migration;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import br.com.caelum.vraptor.VRaptorException;
import br.com.caelum.vraptor.ioc.ApplicationScoped;
import br.com.caelum.vraptor.ioc.Component;

/**
 * Provides connections and database metadata based on a hibernate session
 * factory.
 *
 * You must have a SessionFactory registered on Container, for example, using a
 * ComponentFactory.
 *
 * @author Guilherme Silveira
 */
@Component
@ApplicationScoped
@SuppressWarnings("unchecked")
public class HibernateConnectionProvider implements ConnectionProvider {

	private final SessionFactory factory;

	public HibernateConnectionProvider(SessionFactory factory) {
		this.factory = factory;
	}

	public void apply(Migrations migrations) throws VRaptorException {
		Session session = factory.openSession();
		Transaction tx = null;
		try {
			tx = session.beginTransaction();
			for (Migration migration : migrations.getAll()) {
				execute(session, migration);
			}
			tx.commit();
		} finally {
			if (tx != null && !tx.wasCommitted()) {
				tx.rollback();
			}

			session.close();
		}
	}

	private void execute(Session session, Migration<Session> migration) {
		migration.execute(session);
		session.save(new MigrationInfo(migration.getId()));
	}

	public List<String> getAppliedMigrations() {
		Session session = factory.openSession();
		try {
			return session.createQuery("select id from MigrationInfo").list();
		} finally {
			session.close();
		}
	}

}
