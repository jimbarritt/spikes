package magick;

public class ImageMagick {

}
