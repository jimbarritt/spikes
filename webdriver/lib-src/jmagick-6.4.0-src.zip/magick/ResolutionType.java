package magick;

public interface ResolutionType {

    public final static int UndefinedResolution = 0;
    public final static int PixelsPerInchResolution = 1;
    public final static int PixelsPerCentimeterResolution = 2;

}
